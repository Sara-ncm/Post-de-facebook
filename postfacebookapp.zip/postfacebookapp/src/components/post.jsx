import imgMalteada from "./../assets/Malteada.jpg"
import { useState, useEffect, useRef } from "react";
import CommentForm from "./CommentForm";
import ListComments from "./ListComments";
import "./Postface.css";

let Post = () => {

    // Manejo de estados de los likes
    let [likes, setLike] = useState(0);
    let updateLikes = () => setLike(likes+1)

    // Manejo del boton de comentarios
    let [btnComment, setBtnComment] = useState(false);
    let isShowComment = () => setBtnComment(!btnComment);
    //console.log(btnComment);
    
    //Función para obtener comentarios del formulario
    let [textComment, setTextComment] = useState("");
    let getCommentData = (comment)=>{
        setTextComment(comment);
    }

    //Listado de comentarios
    let listCom = [
        {id:1, text: "Me gusta la malteada de chocolate"},
        {id:2, text: "¿Vende otro sabor?"}
    ];

    let nextID = useRef(3);
    let [listData, setListData] = useState(listCom);

    //Comprobar si hay nuevos comentarios
    useEffect(()=>{
        if(textComment){
        setListData([
            ...listData,
            {id: nextID.current++, text: textComment}
        ]);
    }
}, [textComment]);

// console.log(listCom);
// console.log(listData)

return (
  <div className="card shadow-sm my-3 post-container">
    
    <div className="card-body d-flex align-items-center">
<img
  src="https://cdn.elviajerofisgon.com/wp-content/uploads/2015/07/Helado.jpg"
  alt="profile"
  className="rounded-circle me-2 profile-pic"
/>
      <div>
        <h6 className="mb-0 fw-bold">S&S HELADOS</h6>
        <small className="text-muted">2 h · 🌎 Público</small>
      </div>
    </div>

    <div className="px-3">
      <p className="mb-2">Deliciosa malteada de chocolate 🤤🍫</p>
    </div>

    <img src={imgMalteada} className="card-img-top" alt="malteada" />

    {/* Reacciondes a la publicacion */}
    <div className="px-3 py-2 d-flex justify-content-between border-bottom">
      <span>👍😂 {likes}</span>
      <span>{listData.length} comentarios</span>
    </div>

    {/* Btn interacion */}
    <div className="d-flex justify-content-around py-2 border-bottom">
      <button className="btn btn-light flex-fill fb-btn" onClick={updateLikes}>
        👍 Me gusta
      </button>
      <button className="btn btn-light flex-fill fb-btn" onClick={isShowComment}>
        💬 Comentar
      </button>
      <button className="btn btn-light flex-fill fb-btn">
        ↪️ Compartir
      </button>
    </div>

    {/* 🔹 CAJA DE COMENTARIOS */}
    <div className="px-3 py-2">
      {btnComment && <CommentForm getCommentData={getCommentData} />}
      <ListComments listComData={listData} />
    </div>
  </div>
);

};


export default Post;