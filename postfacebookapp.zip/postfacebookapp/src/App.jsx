import Post from  "./components/post"

function App() {

  return (
    <>
      <Post />
    </>
  )
}

export default App
